﻿  CREATE TABLE "GREAT_CURRENCY" 
   (	"OBJECTIDC" character(3), 
	"OBJECTVERSIONC" integer, 
	"LASTUSERC" character varying(40), 
	"UPDATETIMEC" DATE, 
	"NUM_DECIMAL_DIGITS" double precision, 
	"TEXT_DE" character varying(500), 
	"TEXT_EN" character varying(500), 
	"TEXT_ES" character varying(500), 
	"START_DATE" DATE, 
	"END_DATE" DATE, 
	"FXTYPE" character(1)
   )